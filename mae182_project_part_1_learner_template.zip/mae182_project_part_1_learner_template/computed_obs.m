function [ rho , rhodot ] = computed_obs( t , x , i )
%COMPUTED_OBS Learner template for predicted observations only.
%
% This helper is optional but convenient for debugging.  It should return
% the same rho and rhodot produced inside computed_Htilde, but without the
% partial derivative matrix.

we          = 7.2921158553e-5;    % [rad/s]
theta       = we * t;
c           = cos( theta );
s           = sin( theta );

n           = 10 + 3 * ( i - 1 );
xi          = x(n);
yi          = x(n + 1);
zi          = x(n + 2);

% TODO: implement the observation equations from the handout.
rho         = 0;
rhodot      = 0;

end
