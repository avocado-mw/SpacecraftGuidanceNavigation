function dx = project_dyn( ~ , x )
%PROJECT_DYN Learner template for Project Part I dynamics + STM propagation.
%
% State layout used here:
%   x(1:3)    = ECI position [m]
%   x(4:6)    = ECI velocity [m/s]
%   x(7)      = mu [m^3/s^2]
%   x(8)      = J2 [-]
%   x(9)      = CD [-]
%   x(10:18)  = station coordinates in ECEF [m]
%   x(19:end) = reshaped 9x9 STM
%
% STUDENT TASKS:
%   1) implement the 2-body + J2 + drag accelerations
%   2) call your computed_A(x) function
%   3) propagate the 9x9 STM using Phi_dot = A*Phi

% ------------ %
%  PARAMETERS  %
% ------------ %
Re          = 6378136.3;        % [m]
mu          = x(7);             % [m^3/s^2]
J2          = x(8);             % [-]
Cd          = x(9);             % [-]
S           = 3.0;              % [m^2]
m           = 970;              % [kg]
rho0        = 3.614e-13;        % [kg/m^3]
r0          = 7e5 + Re;         % [m]
H           = 88667.0;          % [m]
thetadot    = 7.2921158553e-5;  % [rad/s]

% ---------- %
%  DYNAMICS  %
% ---------- %
r           = norm( x(1:3) );

% Two-body acceleration
% TODO
a_g_2B      = zeros(3,1);

% J2 acceleration
% TODO
a_g_J2      = zeros(3,1);

% Atmospheric drag acceleration
rhoA        = rho0 * exp( -( r - r0 ) / H );
Va          = [ x(4) + thetadot * x(2); ...
                x(5) - thetadot * x(1); ...
                x(6) ];

% TODO
a_drag      = zeros(3,1);

% Total acceleration
% TODO
a_tot       = a_g_2B + a_g_J2 + a_drag;

% ------------------------- %
%  STATE TRANSITION MATRIX  %
% ------------------------- %
Phi         = reshape( x(19:end) , 9 , 9 );

% TODO: computed_A must return the 9x9 Jacobian for [r;v;mu;J2;CD]
A           = computed_A( x(1:9) );
Phidot      = A * Phi;

% Concatenate derivatives
% Station coordinates are constants in Part I.
dx          = [ x(4:6) ; ...
                a_tot ; ...
                0 ; 0 ; 0 ; ...
                zeros(9,1) ; ...
                reshape( Phidot , 81 , 1 ) ];
end
