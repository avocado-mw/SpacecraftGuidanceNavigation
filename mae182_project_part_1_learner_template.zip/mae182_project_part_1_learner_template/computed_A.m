function A = computed_A( x )
%COMPUTED_A Learner template for the 9x9 linearized dynamics matrix.
%
% Input state for this helper:
%   x = [r(3); v(3); mu; J2; CD]
%
% Output:
%   A = dF/dX for the 9-state subset [r;v;mu;J2;CD]
%
% Part I asks you to show the top-left 6x9 block of A at t0.

%  Planetary parameters
Re          = 6378136.3;        % [m]
mu          = x(7);             % [m^3/s^2]
J2          = x(8);             % [-]

%  Drag parameters
Cd          = x(9);             % [-]
S           = 3.0;              % [m^2]
m           = 970;              % [kg]
rho0        = 3.614e-13;        % [kg/m^3]
r0          = 7e5 + Re;         % [m]
H           = 88667.0;          % [m]
thetadot    = 7.2921158553e-5;  % [rad/s]

r           = norm( x(1:3) );
rhoA        = rho0 * exp( -( r - r0 ) / H );
Va          = [ x(4) + thetadot * x(2); ...
                x(5) - thetadot * x(1); ...
                x(6) ];
VA          = norm( Va ); %#ok<NASGU>

% --------------------------------------------------------------------- %
% STUDENT TASK:
% Fill in the partial derivatives for the 9x9 Jacobian.  The upper-left
% 3x3 and 3x3 kinematic identity structure is straightforward; the lower
% blocks contain the J2 + drag partials and the parameter sensitivities.
% --------------------------------------------------------------------- %
A           = zeros( 9 , 9 );

% Kinematic identities
A(1,4)      = 1;
A(2,5)      = 1;
A(3,6)      = 1;

% TODO: fill in A(4:6,1:9)
% Example placeholders:
% A(4,1) = ...;
% A(4,2) = ...;
% ...
% A(6,9) = ...;

end
