%-------------------------------------------------------------------------%
%    project_part_1
%
%  DESCRIPTION:
%     Learner template for MAE 182 Project -- Part I.
%
%     This starter script is intentionally scaffolded, not completed.  It is
%     designed to help you organize the required steps for Part I:
%       (1) implement the linearized dynamics matrix A and observation-state
%           matrix Htilde,
%       (2) propagate the reference trajectory and the STM,
%       (3) compute predicted observations and residuals,
%       (4) report the requested outputs and RMS values.
%
%  FILES EXPECTED IN THE SAME FOLDER:
%     project_dyn.m
%     computed_A.m
%     computed_Htilde.m
%     computed_obs.m
%     project_obs_data.txt
%
%  STUDENT TASKS:
%     - complete the helper functions
%     - verify dimensions carefully
%     - compare your outputs with the assignment statement
%
%  MAE 182 -- Spacecraft Guidance and Navigation
%-------------------------------------------------------------------------%
clearvars; close all; clc

%% 0) A priori / initial values from the handout
Phi0        = reshape( eye( 9 ) , 9 * 9 , 1 );

% Approximate initial satellite state in ECI [m; m/s]
xv0         = [ [ 757700 , 5222607 , 4851500 ]' ; ...
                [ 2213.21 , 4678.34 , -5371.30 ]' ];

% Station coordinates in ECEF [m]
Xsite0      = [ [ -5127510 , -3794160 , 0 ]' ; ...
                [ 3860910 , 3238490 , 3898094 ]' ; ...
                [ 549505 , -1380872 , 6182197 ]' ];

% Approximate parameters [mu; J2; CD]
param0      = [ 3.986004415E14 ; 1.082626925638815E-3 ; 2.0 ];

% Full initial condition for the propagated state + parameter subset
% x = [r; v; mu; J2; CD; station coordinates]
X0_state    = [ xv0 ; param0 ; Xsite0 ];

% Full ODE state includes the reshaped STM for the 9 dynamic states
X0          = [ X0_state ; Phi0 ];

%% 1) Integrate reference trajectory and STM
% Part I requires propagation from t = 0 to t = 18340 s.
tol         = 1e-12;
tstep       = 0.1;
time        = 0:tstep:18340;
options     = odeset( 'RelTol' , tol , 'AbsTol' , tol );

% TODO: ensure project_dyn.m is fully implemented before running this line.
[ ~ , X ]   = ode45( @project_dyn , time , X0 , options );

%% 2) Unpack propagated state and STM
% First 18 states are [r;v;mu;J2;CD;station coords].
x_temp      = X(:,1:18)';

% Optional sanity check: should look like a near-polar LEO ellipse.
figure(1)
plot3( x_temp(1,:) , x_temp(2,:) , x_temp(3,:) , 'k-' )
grid on; axis equal
xlabel('x [m]'); ylabel('y [m]'); zlabel('z [m]')
title('Reference trajectory in ECI')

% Reshape the propagated 9x9 STM.
Phi_temp    = X(:,19:end)';
Phi_temp    = reshape( Phi_temp , 9 , 9 , length(time) );

%% 3) Resample every 20 seconds
rsmpl       = round( 20 / tstep );
lng_rsmpl   = round( length(time) / rsmpl ) + 1;

t           = zeros( lng_rsmpl , 1 );
x           = zeros( 18 , lng_rsmpl );
Phi         = zeros( 18 , 18 , lng_rsmpl );

for k = 1:lng_rsmpl
   idx          = rsmpl * (k - 1) + 1;
   t(k)         = time(idx);
   x(:,k)       = x_temp(:,idx);

   % Only the 9x9 dynamic block is propagated here.  The remaining station
   % coordinates are treated as constants in Part I, so the lower-right block
   % is the identity.
   Phi(:,:,k)   = [ Phi_temp(:,:,idx) , zeros( 9 , 9 ) ; ...
                    zeros( 9 , 9 )    , eye( 9 , 9 )   ];
end

%% 4) Load and organize observation data
Y           = load('project_obs_data.txt');

% Convert observation time [s] to index into the 20-second resampled arrays.
Y(:,1)      = round( Y(:,1) / 20 ) + 1;

% Map station IDs {101,337,394} to local indices {1,2,3}.
Y( Y(:,2) == 101 , 2 ) = 1;
Y( Y(:,2) == 337 , 2 ) = 2;
Y( Y(:,2) == 394 , 2 ) = 3;

lng_obs     = numel( Y(:,1) );

%% 5) Predicted observations, Htilde, and residuals
rho         = zeros( lng_obs , 1 );
rhodot      = zeros( lng_obs , 1 );
Htilde      = zeros( 2 , 18 , lng_obs );
y           = zeros( 2 , lng_obs );

for k = 1:lng_obs
    j = Y(k,1);     % observation-time index in the resampled arrays

    % TODO: computed_Htilde.m must return Htilde, rho, rhodot.
    [ Htilde(:,:,k) , rho(k,1) , rhodot(k,1) ] = computed_Htilde( t(j) , x(:,j) , Y(k,2) );

    % Observation residuals (O - C)
    y(:,k) = Y(k,3:4)' - [ rho(k,1) ; rhodot(k,1) ];
end

%% 6) RMS values
rho_res     = y(1,:);
rhodot_res  = y(2,:);

rho_rms     = sqrt( sum( rho_res.^2 ) / lng_obs );
rhodot_rms  = sqrt( sum( rhodot_res.^2 ) / lng_obs );

disp( [ 'range_rms = ' , num2str(rho_rms) , ' m' ] );
disp( [ 'range_rate_rms = ' , num2str(rhodot_rms) , ' m/s' ] );

%% 7) Required residual plots
hFig = figure(2);
plot( rho_res , 'k-' )
grid on
hTitle = title( 'Range Residuals' );
hXLabel = xlabel( 'observation number' );
hYLabel = ylabel( 'O - C [m]' );
set( gca , 'FontName' , 'Helvetica' );
set( [ hTitle , hXLabel , hYLabel ], 'FontName' , 'AvantGarde' );
set( [ hTitle , hXLabel , hYLabel ] , 'FontSize' , 12 );

hFig = figure(3);
plot( rhodot_res , 'k-' )
grid on
hTitle = title( 'Range-Rate Residuals' );
hXLabel = xlabel( 'observation number' );
hYLabel = ylabel( 'O - C [m/s]' );
set( gca , 'FontName' , 'Helvetica' );
set( [ hTitle , hXLabel , hYLabel ], 'FontName' , 'AvantGarde' );
set( [ hTitle , hXLabel , hYLabel ] , 'FontSize' , 12 );

%% 8) Requested outputs for checking
% Part I explicitly asks for Htilde and the upper-left 6x9 block of A at t0,
% as well as r, v, and Phi at final time.
A0          = computed_A( X0_state );
Htilde0     = Htilde(:,:,1);
xvf         = x(1:6,end);
Phif        = Phi(:,:,end);
residuals0  = y(:,1);

% Save a compact results file for later use / debugging.
save project_part_1_results A0 Htilde0 xvf Phif residuals0 rho_rms rhodot_rms

%% 9) Student reminder
fprintf('\nProject Part I reminder:\n');
fprintf('  • Show the output of Htilde(t0).\n');
fprintf('  • Show the top-left 6x9 block of A(t0).\n');
fprintf('  • Show r(tf), v(tf), and Phi(tf,t0).\n');
fprintf('  • Report the range and range-rate RMS values.\n');
