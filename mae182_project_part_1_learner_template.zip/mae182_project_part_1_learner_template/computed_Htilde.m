function [ Htilde , rho , rhodot ] = computed_Htilde( t , x , i )
%COMPUTED_HTILDE Learner template for Project Part I observation partials.
%
% Inputs:
%   t  = time past epoch [s]
%   x  = full 18x1 state [r;v;mu;J2;CD;station coords]
%   i  = station index in {1,2,3}
%
% Outputs:
%   Htilde = 2x18 observation-state matrix
%   rho    = predicted range [m]
%   rhodot = predicted range-rate [m/s]

we          = 7.2921158553e-5;    % [rad/s]
theta       = we * t;
c           = cos( theta );
s           = sin( theta );

% Station coordinates in ECEF
n           = 10 + 3 * ( i - 1 );
xi          = x(n);
yi          = x(n + 1);
zi          = x(n + 2);

% ------------------------------------------------------------------ %
% STUDENT TASK:
% Implement rho, rhodot, and the corresponding Htilde partials from the
% assignment statement.
% ------------------------------------------------------------------ %

% TODO: predicted range
rho         = 0;

% TODO: predicted range-rate
rhodot      = 0;

% TODO: Htilde partials
Htilde      = zeros( 2 , 18 );

end
